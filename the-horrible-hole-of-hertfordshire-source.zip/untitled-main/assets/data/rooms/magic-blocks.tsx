<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="magic-blocks" tilewidth="64" tileheight="64" tilecount="8" columns="4">
 <image source="../../art/magic-blocks.png" width="256" height="128"/>
 <tile id="0" type="magic-hole">
  <properties>
   <property name="character" value="O"/>
  </properties>
 </tile>
 <tile id="1" type="magic-hole">
  <properties>
   <property name="character" value="P"/>
  </properties>
 </tile>
 <tile id="2" type="magic-hole">
  <properties>
   <property name="character" value="E"/>
  </properties>
 </tile>
 <tile id="3" type="magic-hole">
  <properties>
   <property name="character" value="N"/>
  </properties>
 </tile>
 <tile id="4" type="magic-block">
  <properties>
   <property name="character" value="O"/>
  </properties>
 </tile>
 <tile id="5" type="magic-block">
  <properties>
   <property name="character" value="P"/>
  </properties>
 </tile>
 <tile id="6" type="magic-block">
  <properties>
   <property name="character" value="E"/>
  </properties>
 </tile>
 <tile id="7" type="magic-block">
  <properties>
   <property name="character" value="N"/>
  </properties>
 </tile>
</tileset>
