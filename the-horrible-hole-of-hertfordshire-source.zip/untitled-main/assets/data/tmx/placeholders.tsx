<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="placeholder" tilewidth="64" tileheight="64" tilecount="9" columns="3">
 <image source="../../art/placeholder.png" width="192" height="192"/>
 <tile id="0" type="door"/>
 <tile id="1" type="player"/>
 <tile id="2" type="stone"/>
 <tile id="3" type="wall"/>
 <tile id="7" type="monster"/>
 <tile id="8" type="hole"/>
</tileset>
