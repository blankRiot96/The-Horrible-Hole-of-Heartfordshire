import pygame

ColorValue = pygame.Color | str | tuple[int, int, int] | tuple[int, int, int, int]
Coordinate = tuple[int, int]
